#!/system/bin/sh
# service.sh — Magisk/KernelSU late-start. Mirrors init.mt6833.rc + init.everpal.rc (v1).

TAG="[everpal-ram-mgmt]"

write() {
    local path="$1" val="$2"
    if [ -w "$path" ]; then
        echo "$val" > "$path"
        echo "$TAG set $path = $val"
    else
        echo "$TAG SKIP $path (not writable)" >&2
    fi
}

do_resetprop() {
    local k="$1" v="$2"
    if command -v resetprop >/dev/null 2>&1; then
        resetprop "$k" "$v"
    elif [ -x /data/adb/ksu/bin/resetprop ]; then
        /data/adb/ksu/bin/resetprop "$k" "$v"
    elif [ -x /data/adb/magisk/resetprop ]; then
        /data/adb/magisk/resetprop "$k" "$v"
    elif [ -x /data/adb/ap/bin/resetprop ]; then
        /data/adb/ap/bin/resetprop "$k" "$v"
    elif [ -x /system/bin/resetprop ]; then
        /system/bin/resetprop "$k" "$v"
    fi
}

# ── Detect Physical RAM & CPU Topology dynamically ───────────────────────
MEM_TOTAL_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null)
[ -z "$MEM_TOTAL_KB" ] && MEM_TOTAL_KB=3709888
MEM_TOTAL_MB=$(( MEM_TOTAL_KB / 1024 ))

CPU_CORES=$(nproc 2>/dev/null || cat /sys/devices/system/cpu/present 2>/dev/null | awk -F'-' '{print $2+1}')
[ -z "$CPU_CORES" ] || [ "$CPU_CORES" -le 0 ] && CPU_CORES=8

# ── Dynamic Variant Sizing (4GB / 6GB / 8GB MT6833 Family) ───────────────
if [ "$MEM_TOTAL_MB" -ge 7000 ]; then
    # 8GB Physical RAM Variant (~7.5GB Linux MemTotal)
    ZRAM_SIZE_BYTES=$(( (MEM_TOTAL_KB * 1024 * 75) / 100 ))
    MIN_FREE_KB=40960
    BG_APPS=128
    PHANTOM_APPS=48
elif [ "$MEM_TOTAL_MB" -ge 5000 ]; then
    # 6GB Physical RAM Variant (~5.5GB Linux MemTotal)
    ZRAM_SIZE_BYTES=$(( (MEM_TOTAL_KB * 1024 * 75) / 100 ))
    MIN_FREE_KB=32768
    BG_APPS=96
    PHANTOM_APPS=40
else
    # 4GB Physical RAM Variant (~3.53GB Linux MemTotal)
    # Calibrated to 3,758,096,384 bytes (3.58GB), 24MB min_free, 64 cached apps
    ZRAM_SIZE_BYTES=3758096384
    MIN_FREE_KB=24576
    BG_APPS=64
    PHANTOM_APPS=32
fi

# ── ZRAM: Adaptive Expansion with LZ4 & Parallel CPU Streams ───────────────
if [ -b /dev/block/zram0 ]; then
    CURRENT_SIZE=$(cat /sys/block/zram0/disksize 2>/dev/null)
    if [ "$CURRENT_SIZE" != "$ZRAM_SIZE_BYTES" ]; then
        swapoff /dev/block/zram0 2>/dev/null
        echo 1 > /sys/block/zram0/reset 2>/dev/null
        echo "lz4" > /sys/block/zram0/comp_algorithm 2>/dev/null
        echo "$CPU_CORES" > /sys/block/zram0/max_comp_streams 2>/dev/null
        echo "$ZRAM_SIZE_BYTES" > /sys/block/zram0/disksize 2>/dev/null
        mkswap /dev/block/zram0 2>/dev/null
        swapon /dev/block/zram0 2>/dev/null
        echo "$TAG zram0 resized dynamically to ${ZRAM_SIZE_BYTES} bytes (LZ4, ${CPU_CORES} streams) for ${MEM_TOTAL_MB}MB RAM"
    else
        echo "$CPU_CORES" > /sys/block/zram0/max_comp_streams 2>/dev/null
        echo "$TAG zram0 already optimal (${ZRAM_SIZE_BYTES} bytes, ${CPU_CORES} streams)"
    fi
fi

# ── VM / memory management (swappiness 80, wsf 20, adaptive min_free) ─────
write /proc/sys/vm/swappiness               80
write /proc/sys/vm/watermark_scale_factor   20
write /proc/sys/vm/min_free_kbytes          $MIN_FREE_KB
write /sys/kernel/mm/swap/vma_ra_enabled    false
write /proc/sys/vm/page-cluster             0
write /proc/sys/vm/vfs_cache_pressure       80
write /proc/sys/vm/dirty_ratio              30
write /proc/sys/vm/dirty_background_ratio   10

# ── Storage I/O Optimization (UFS 2.2) ────────────────────────────────────
for d in /sys/block/sd*; do
    [ -f "$d/queue/read_ahead_kb" ] && write "$d/queue/read_ahead_kb" 512
    [ -f "$d/queue/iostats" ] && write "$d/queue/iostats" 0
done

# ── Post-boot (Linux 4.14: compact_memory, not compaction_proactiveness) ──
write /proc/sys/vm/stat_interval            10
write /proc/sys/vm/compact_memory           1

# ── Runtime LMK & AM property updates (Adaptive RAM Scaling) ──────────────
do_resetprop persist.sys.fw.bg_apps_limit "$BG_APPS"
do_resetprop persist.device_config.activity_manager.max_cached_processes "$BG_APPS"
do_resetprop persist.device_config.activity_manager.max_phantom_processes "$PHANTOM_APPS"
do_resetprop ro.lmk.thrashing_limit 300
do_resetprop ro.lmk.thrashing_limit_decay 15
do_resetprop ro.lmk.downgrade_pressure 80
do_resetprop ro.lmk.swap_util_max 90
do_resetprop ro.lmk.swap_free_low_percentage 2
do_resetprop ro.lmk.kill_heaviest_task false
do_resetprop ro.lmk.psi_partial_stall_ms 250
do_resetprop ro.lmk.psi_complete_stall_ms 800
do_resetprop ro.lmk.kill_timeout_ms 250
do_resetprop ro.lmk.critical_upgrade false

echo "$TAG all RAM tweaks applied dynamically for ${MEM_TOTAL_MB}MB device tier"
