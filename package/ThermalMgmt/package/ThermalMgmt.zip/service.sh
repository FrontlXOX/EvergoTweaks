#!/system/bin/sh
# service.sh — Magisk/KernelSU late-start. Hardware Compute Master v1.

TAG="[everpal-thermal-master]"

write() {
    local path="$1" val="$2"
    if [ -w "$path" ]; then
        echo "$val" > "$path"
        echo "$TAG set $path = $val"
    else
        echo "$TAG SKIP $path (not writable)" >&2
    fi
}

lock_node() {
    local path="$1" val="$2"
    if [ -e "$path" ]; then
        chmod 644 "$path" 2>/dev/null
        echo "$val" > "$path" 2>/dev/null
        chmod 444 "$path" 2>/dev/null
        echo "$TAG LOCKED $path = $val (read-only)"
    fi
}

log -t "$TAG" "Applying Everpal Hardware Compute Master v1..."

# 1. Thermal Governor & Sconfig 10
setprop sys.thermal.mode 10
setprop sys.thermal.config thermal-nolimits.conf
setprop persist.sys.thermal.mode 10
setprop persist.sys.thermal.config thermal-nolimits.conf

if [ -f /sys/class/thermal/thermal_message/sconfig ]; then
    write /sys/class/thermal/thermal_message/sconfig 10
fi

# Reset any stuck throttling floors
write /proc/driver/thermal/cl_kpi 0
write /proc/driver/thermal/cl_sdm_kpi 0

# 2. MediaTek CoreLink CCI Hardware Interconnect Lock (1.60 GHz Mode)
for cci in /sys/devices/platform/10012000.dvfsrc/dvfsrc_force_vcore_opp \
           /sys/devices/platform/soc/10012000.dvfsrc/dvfsrc_force_vcore_opp \
           /proc/driver/dvfsrc/force_vcore_opp; do
    if [ -e "$cci" ]; then
        lock_node "$cci" 0
    fi
done

# 3. ARM Mali-G57 MC2 GPU Acceleration & DVFS Lock (50ms Evaluation)
for dvfs_p in /sys/module/pvrsrvkm/parameters/gpu_dvfs_period \
              /sys/devices/platform/13040000.mali/gpu_dvfs_period \
              /sys/devices/platform/soc/13040000.mali/gpu_dvfs_period; do
    if [ -e "$dvfs_p" ]; then
        lock_node "$dvfs_p" 50
    fi
done

for gpower in /sys/devices/platform/13040000.mali/power_policy \
              /sys/devices/platform/soc/13040000.mali/power_policy; do
    if [ -e "$gpower" ]; then
        write "$gpower" "always_on"
    fi
done

# MediaTek GED Boost & GPU Freq Clamps
for ged in /sys/module/ged/parameters; do
    if [ -d "$ged" ]; then
        write "$ged/gpu_bottom_freq" 955000
        write "$ged/gpu_cust_boost_freq" 1068000
        write "$ged/gpu_cust_upbound_freq" 1068000
        write "$ged/ged_boost_enable" 1
        write "$ged/ged_smart_boost" 1
        write "$ged/boost_extra_freq" 1068000
        write "$ged/boost_gpu_enable" 1
        write "$ged/boost_upper_bound" 1068000
        write "$ged/enable_game_self_frc" 1
        write "$ged/gx_game_mode" 1
        write "$ged/gx_frc_mode" 1
        write "$ged/gx_boost_on" 1
        write "$ged/is_ged_srv_running" 1
    fi
done

# 4. CPU Schedutil Latency Elimination & BORE Optimization
for pol in /sys/devices/system/cpu/cpufreq/policy*; do
    if [ -d "$pol" ]; then
        write "$pol/schedutil/up_rate_limit_us" 0
        write "$pol/schedutil/down_rate_limit_us" 500
        write "$pol/schedutil/iowait_boost_enable" 1
    fi
done

write /proc/sys/kernel/sched_migration_cost_ns 250000
write /dev/cpuset/top-app/cpu.shares 10240
write /dev/cpuset/foreground/cpu.shares 8192
write /dev/cpuset/foreground/cpus 0-7
write /dev/cpuset/top-app/cpus 0-7

# 5. Network & Wi-Fi Latency Stabilization
write /proc/sys/net/ipv4/tcp_slow_start_after_idle 0
write /proc/sys/net/ipv4/tcp_keepalive_time 60
write /proc/sys/net/ipv4/tcp_keepalive_intvl 10
write /proc/sys/net/ipv4/tcp_keepalive_probes 5

log -t "$TAG" "Everpal Hardware Compute Master v1 applied successfully."
