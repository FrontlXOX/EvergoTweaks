#!/system/bin/sh
# Everpal Thermal Master Service (v1)
# Prepared By: Shovit Dutta | Author / Research: Addster09 x Shovit Dutta
# Module Author: TesterProd

LOG="/data/adb/everpal-thermal.log"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG"
}

write() {
    local path="$1" val="$2"
    if [ -f "$path" ] || [ -w "$path" ]; then
        chmod 664 "$path" 2>/dev/null
        echo "$val" > "$path" 2>/dev/null
        log_msg "set $path = $val"
    fi
}

# Wait for system boot completion
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done

sleep 3
log_msg "Everpal Thermal Master v1 initializing..."

# 1. Enforce sconfig 10 (Xiaomi MT6833 High-Performance Mobile Game / NoLimits Profile)
# Verified: sconfig 10 unlocks 100% 2.0GHz Cortex-A55 and 2.4GHz Cortex-A76 clocks with 55°C headroom
write /sys/class/thermal/thermal_message/sconfig 10

# 2. Verify and enforce full CPU scaling max frequencies
for p in /sys/devices/system/cpu/cpufreq/policy*; do
    if [ -f "$p/scaling_max_freq" ] && [ -f "$p/cpuinfo_max_freq" ]; then
        max_f=$(cat "$p/cpuinfo_max_freq")
        echo "$max_f" > "$p/scaling_max_freq" 2>/dev/null
    fi
done
log_msg "CPU scaling policy max frequencies verified uncapped."

# 3. CPU Schedutil Governor Instant Ramp-Up (0 µs debounce) & Frequency Hold (20 ms)
# Eliminates clock ramp latency across Cortex-A76 Big cores (policy6) and LITTLE cores (policy0)
write /sys/devices/system/cpu/cpufreq/policy6/schedutil/up_rate_limit_us 0
write /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us 0
write /sys/devices/system/cpu/cpufreq/policy6/schedutil/down_rate_limit_us 20000
write /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us 20000

# 4. MediaTek CoreLink Cache Coherent Interconnect (CCI) Perf Mode Hardware Lock
# Mode 1: Boosts interconnect and L3 cache coherency bandwidth between A76 and A55 clusters to 1.6 GHz (OPP 0)
# chmod 444 blocks non-root Power HAL from reverting to Normal mode (OPP 3-6)
write /proc/cpufreq/cpufreq_cci_mode 1
chmod 444 /proc/cpufreq/cpufreq_cci_mode 2>/dev/null

# Unlocks peak LPDDR4X transfer rate to 4.266 GHz (OPP 0) and Vcore to 725 mV
[ -f /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_ddr_opp ] && echo 0 > /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_ddr_opp 2>/dev/null
[ -f /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_vcore_opp ] && echo 0 > /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_vcore_opp 2>/dev/null
[ -f /proc/perfmgr/boost_ctrl/dram_ctrl/ddr ] && echo 0 > /proc/perfmgr/boost_ctrl/dram_ctrl/ddr 2>/dev/null

# MediaTek PPM (Processor Power Management) Power Budget Uncap
# Policy 3 (PWR_THRO) enforces artificial power ceilings; disabling unlocks full compute
# Policy 5 (DLPT) is preserved enabled to prevent kernel printk spam and PMIC current dip
[ -f /proc/ppm/policy_status ] && echo 3 0 > /proc/ppm/policy_status 2>/dev/null
[ -f /proc/ppm/policy_status ] && echo 5 1 > /proc/ppm/policy_status 2>/dev/null

# 5. MediaTek Native CPU DVFS Power Mode (Sports Mode)
# Mode 3: Performance(Sports) mode maximizes clock residency and eliminates power-throttling hysteresis
write /proc/cpufreq/cpufreq_power_mode 3

# 6. CPU Cpuset Architecture: Unlock Both Big Cores for Foreground
# Stock AOSP restricts foreground to 0-6 (locks out CPU 7). Unlocking to 0-7 enables full 8-core compute
write /dev/cpuset/foreground/cpus 0-7
write /dev/stune/foreground/schedtune.prefer_idle 1

# 7. BORE & Task Placement Optimization
# BORE (Burst-Oriented Response Enhancer) & Task Placement Optimization
# sched_latency_ns: 24ms native BORE timeslice prevents context-switching thrashing across 8 cores
# sched_min_granularity_ns: 3ms minimal CPU-bound execution chunk
# sched_wakeup_granularity_ns: 4ms eliminates thread preemption jitter
# sched_migration_cost_ns: 350µs allows Big-core work stealing at barriers while preserving cache
# sched_nr_migrate: 128 allows full thread balancing across 8 cores without truncation
# sched_walt_init_task_load_pct: 40 places new worker threads directly on Big cores
write /proc/sys/kernel/sched_big_task_rotation 1
[ -f /proc/perfmgr/boost_ctrl/eas_ctrl/sched_big_task_rotation ] && echo 1 > /proc/perfmgr/boost_ctrl/eas_ctrl/sched_big_task_rotation 2>/dev/null
write /proc/sys/kernel/sched_child_runs_first 1
write /proc/sys/kernel/sched_latency_ns 24000000
write /proc/sys/kernel/sched_min_granularity_ns 3000000
write /proc/sys/kernel/sched_wakeup_granularity_ns 4000000
write /proc/sys/kernel/sched_migration_cost_ns 250000
[ -f /proc/perfmgr/boost_ctrl/eas_ctrl/m_sched_migrate_cost_n ] && echo 250000 > /proc/perfmgr/boost_ctrl/eas_ctrl/m_sched_migrate_cost_n 2>/dev/null
write /proc/sys/kernel/sched_nr_migrate 128
write /proc/sys/kernel/sched_walt_init_task_load_pct 40
write /dev/cpuctl/top-app/cpu.shares 10240

# 8. Schedtune Top-App Foreground Acceleration
write /dev/stune/top-app/schedtune.boost 25
write /dev/stune/top-app/schedtune.prefer_idle 1

# 9. MediaTek Hardware EAS Controller (CGroup 3 = Top-App)
[ -f /proc/perfmgr/boost_ctrl/eas_ctrl/perfserv_prefer_idle ] && echo "3 1" > /proc/perfmgr/boost_ctrl/eas_ctrl/perfserv_prefer_idle 2>/dev/null
[ -f /proc/perfmgr/boost_ctrl/eas_ctrl/perfserv_ta_boost ] && echo "25" > /proc/perfmgr/boost_ctrl/eas_ctrl/perfserv_ta_boost 2>/dev/null

# 10. ARM Mali-G57 MC2 GPU Platform & Power Policy Acceleration
# always_on prevents shader core power-gating and wakeup latency between frames
# 50ms dvfs_period enables 2x faster reaction to 3D rendering spikes; chmod 444 blocks Power HAL overwrite
write /sys/devices/platform/13000000.mali/power_policy always_on
write /sys/devices/platform/13000000.mali/dvfs_period 50
chmod 444 /sys/devices/platform/13000000.mali/dvfs_period 2>/dev/null
write /sys/devices/platform/13000000.mali/js_scheduling_period 50

# 11. MediaTek GED (Graphics Enforcement Daemon) GPU Acceleration
# Uncaps ARM Mali-G57 MC2 up to 1068 MHz and enforces real-time frame synchronization
write /sys/module/ged/parameters/boost_gpu_enable 1
write /sys/module/ged/parameters/enable_gpu_boost 1
write /sys/module/ged/parameters/ged_boost_enable 1
write /sys/module/ged/parameters/ged_smart_boost 1
write /sys/module/ged/parameters/gx_game_mode 1
write /sys/module/ged/parameters/gx_force_cpu_boost 1
write /sys/module/ged/parameters/gx_boost_on 1
write /sys/module/ged/parameters/gpu_bottom_freq 955000
write /sys/module/ged/parameters/gpu_cust_boost_freq 1068000
write /sys/module/ged/parameters/gpu_cust_upbound_freq 1068000

# 12. UFS 2.2 Storage I/O Optimization
for d in /sys/block/sd*; do
    [ -f "$d/queue/read_ahead_kb" ] && echo 512 > "$d/queue/read_ahead_kb" 2>/dev/null
    [ -f "$d/queue/iostats" ] && echo 0 > "$d/queue/iostats" 2>/dev/null
done

# 13. Network & TCP Wi-Fi ADB Stability
# Prevents congestion window collapse and socket timeouts during heavy benchmark/compute bursts
write /proc/sys/net/ipv4/tcp_slow_start_after_idle 0
write /proc/sys/net/ipv4/tcp_keepalive_time 60
write /proc/sys/net/ipv4/tcp_keepalive_intvl 10
write /proc/sys/net/ipv4/tcp_keepalive_probes 5

# 14. Memory Compaction
write /proc/sys/vm/compact_memory 1

# 15. Delayed Background Re-Enforcement (Locks out Power HAL late-initialization)
(
    sleep 25
    chmod 664 /proc/cpufreq/cpufreq_cci_mode 2>/dev/null
    echo 1 > /proc/cpufreq/cpufreq_cci_mode 2>/dev/null
    chmod 444 /proc/cpufreq/cpufreq_cci_mode 2>/dev/null

    chmod 664 /sys/devices/platform/13000000.mali/dvfs_period 2>/dev/null
    echo 50 > /sys/devices/platform/13000000.mali/dvfs_period 2>/dev/null
    chmod 444 /sys/devices/platform/13000000.mali/dvfs_period 2>/dev/null

    [ -f /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_ddr_opp ] && echo 0 > /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_ddr_opp 2>/dev/null
    [ -f /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_vcore_opp ] && echo 0 > /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_vcore_opp 2>/dev/null
    [ -f /proc/perfmgr/boost_ctrl/dram_ctrl/ddr ] && echo 0 > /proc/perfmgr/boost_ctrl/dram_ctrl/ddr 2>/dev/null

    [ -f /proc/ppm/policy_status ] && echo 3 0 > /proc/ppm/policy_status 2>/dev/null
    [ -f /proc/ppm/policy_status ] && echo 5 1 > /proc/ppm/policy_status 2>/dev/null
    [ -f /proc/perfmgr/boost_ctrl/eas_ctrl/sched_big_task_rotation ] && echo 1 > /proc/perfmgr/boost_ctrl/eas_ctrl/sched_big_task_rotation 2>/dev/null
    [ -f /proc/perfmgr/boost_ctrl/eas_ctrl/m_sched_migrate_cost_n ] && echo 250000 > /proc/perfmgr/boost_ctrl/eas_ctrl/m_sched_migrate_cost_n 2>/dev/null
    echo 250000 > /proc/sys/kernel/sched_migration_cost_ns 2>/dev/null
    echo 10240 > /dev/cpuctl/top-app/cpu.shares 2>/dev/null
    [ -f /proc/perfmgr/boost_ctrl/eas_ctrl/perfserv_ta_boost ] && echo "25" > /proc/perfmgr/boost_ctrl/eas_ctrl/perfserv_ta_boost 2>/dev/null
    echo 128 > /proc/sys/kernel/sched_nr_migrate 2>/dev/null
    echo 40 > /proc/sys/kernel/sched_walt_init_task_load_pct 2>/dev/null
    chmod 664 /sys/module/ged/parameters/gpu_bottom_freq 2>/dev/null
    echo 955000 > /sys/module/ged/parameters/gpu_bottom_freq 2>/dev/null
    echo 1068000 > /sys/module/ged/parameters/gpu_cust_boost_freq 2>/dev/null
    echo 1068000 > /sys/module/ged/parameters/gpu_cust_upbound_freq 2>/dev/null
    echo 1 > /sys/module/ged/parameters/ged_smart_boost 2>/dev/null
    echo 1 > /sys/module/ged/parameters/boost_gpu_enable 2>/dev/null
    echo 1 > /sys/module/ged/parameters/enable_gpu_boost 2>/dev/null
    echo 1 > /sys/module/ged/parameters/ged_boost_enable 2>/dev/null
    echo 1 > /sys/module/ged/parameters/gx_game_mode 2>/dev/null
    log_msg "Post-boot re-assertion complete. CoreLink CCI, Mali DVFS, PPM uncap, DVFSRC DDR, and GED 955MHz locked."
) &

# 16. Guardrails:
# - NEVER write to /proc/driver/thermal/set_sspm_big_limit_threshold (triggers unkillable 84% CPU kernel IPI spinloop)
# - NEVER touch mtk-cl-backlight cooling device (drops PWM brightness to 0 causing black screen)
# - NEVER force settings min_refresh_rate (preserves smooth Android 16 display composer)

log_msg "Everpal Thermal Master v1 armed and active successfully."
