MODDIR=${0%/*}

V4A_LOG=/data/adb/viper_install.log
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [post-fs-data] $1" >> $V4A_LOG; }

log "---> post-fs-data start <---"
log "SELinux: $(getenforce 2>/dev/null || echo unknown)"

if [ -f "$MODDIR/system/vendor/etc/audio_effects_config.xml" ]; then
  CHCON_ERR=$(chcon u:object_r:vendor_configs_file:s0 "$MODDIR/system/vendor/etc/audio_effects_config.xml" 2>&1) || log "chcon bundled config failed: $CHCON_ERR"
  log "Set chcon on bundled audio_effects_config.xml"
fi

SHM_DIR=/data/local/tmp/v4a
SHM_STATUS=$SHM_DIR/shm_status.bin
SHM_PARAMS=$SHM_DIR/shm_params.bin
SHM_BULK=$SHM_DIR/shm_bulk.bin
STATUS_SIZE=256
PARAM_SIZE=4096
BULK_SIZE=4096

mkdir -p $SHM_DIR
chmod 777 $SHM_DIR
CHCON_ERR=$(chcon u:object_r:shell_data_file:s0 $SHM_DIR 2>&1) || log "chcon SHM dir failed: $CHCON_ERR"
log "SHM dir created: $(ls -ldZ $SHM_DIR 2>/dev/null | awk '{print $1, $5}')"

dd if=/dev/zero of=$SHM_STATUS bs=$STATUS_SIZE count=1 2>/dev/null
log "Created shm_status.bin ($STATUS_SIZE bytes)"
dd if=/dev/zero of=$SHM_PARAMS bs=$PARAM_SIZE count=1 2>/dev/null
log "Created shm_params.bin ($PARAM_SIZE bytes)"
dd if=/dev/zero of=$SHM_BULK   bs=$BULK_SIZE   count=1 2>/dev/null
log "Created shm_bulk.bin ($BULK_SIZE bytes)"

KERNEL_DIR=$SHM_DIR/kernel
mkdir -p $KERNEL_DIR
chmod 777 $KERNEL_DIR
CHCON_ERR=$(chcon u:object_r:shell_data_file:s0 $KERNEL_DIR 2>&1) || log "chcon kernel dir failed: $CHCON_ERR"
log "Kernel dir created: $(ls -ldZ $KERNEL_DIR 2>/dev/null | awk '{print $1, $5}')"

chmod 666 $SHM_STATUS $SHM_PARAMS $SHM_BULK
CHCON_ERR=$(chcon u:object_r:shell_data_file:s0 $SHM_STATUS $SHM_PARAMS $SHM_BULK 2>&1) || log "chcon SHM files failed: $CHCON_ERR"

log "SHM files:"
for f in $SHM_STATUS $SHM_PARAMS $SHM_BULK; do
  log "  $f: $(ls -lZ "$f" 2>/dev/null | awk '{print $1, $4, $5}')"
done

V4A_SEPOLICY="allow hal_audio_default shell_data_file dir { search read open getattr write add_name remove_name rename }
allow hal_audio_default shell_data_file file { read write create open getattr setattr unlink rename map }
allow mtk_hal_audio shell_data_file dir { search read open getattr write add_name remove_name rename }
allow mtk_hal_audio shell_data_file file { read write create open getattr setattr unlink rename map }
allow untrusted_app shell_data_file dir { search read open getattr }
allow untrusted_app shell_data_file file { read write open getattr map }"

POLICY_TOOL=""
POLICY_TYPE=""
if command -v magiskpolicy >/dev/null 2>&1; then
  POLICY_TOOL="magiskpolicy"
  POLICY_TYPE="magisk"
elif [ -x /data/adb/magisk/magiskpolicy ]; then
  POLICY_TOOL="/data/adb/magisk/magiskpolicy"
  POLICY_TYPE="magisk"
elif command -v ksud >/dev/null 2>&1; then
  POLICY_TOOL="ksud"
  POLICY_TYPE="ksu"
elif [ -x /data/adb/ksu/bin/ksud ]; then
  POLICY_TOOL="/data/adb/ksu/bin/ksud"
  POLICY_TYPE="ksu"
elif [ -x /data/adb/ap/bin/apd ]; then
  POLICY_TOOL="/data/adb/ap/bin/apd"
  POLICY_TYPE="apatch"
fi

log "Applying SELinux policy rules (tool: ${POLICY_TOOL:-not found}, type: ${POLICY_TYPE:-unknown})..."
if [ -n "$POLICY_TOOL" ]; then
  case "$POLICY_TYPE" in
    ksu)
      RULE_FILE="$MODDIR/v4a_sepolicy.tmp"
      echo "$V4A_SEPOLICY" > "$RULE_FILE"
      POLICY_ERR=$($POLICY_TOOL sepolicy apply "$RULE_FILE" 2>&1)
      POLICY_RC=$?
      rm -f "$RULE_FILE"
      ;;
    apatch)
      RULE_FILE="$MODDIR/v4a_sepolicy.tmp"
      echo "$V4A_SEPOLICY" > "$RULE_FILE"
      POLICY_ERR=$($POLICY_TOOL sepolicy --live --apply "$RULE_FILE" 2>&1)
      POLICY_RC=$?
      rm -f "$RULE_FILE"
      ;;
    magisk)
      POLICY_ERR=$($POLICY_TOOL --live \
        "allow hal_audio_default shell_data_file dir { search read open getattr write add_name remove_name rename }" \
        "allow hal_audio_default shell_data_file file { read write create open getattr setattr unlink rename map }" \
        "allow mtk_hal_audio shell_data_file dir { search read open getattr write add_name remove_name rename }" \
        "allow mtk_hal_audio shell_data_file file { read write create open getattr setattr unlink rename map }" \
        "allow untrusted_app shell_data_file dir { search read open getattr }" \
        "allow untrusted_app shell_data_file file { read write open getattr map }" \
        2>&1)
      POLICY_RC=$?
      ;;
  esac
  if [ $POLICY_RC -ne 0 ]; then
    log "Policy inject failed (rc=$POLICY_RC): $POLICY_ERR"
  else
    log "Policy inject applied (rc=0)"
  fi
else
  log "WARNING: No policy tool found. Relying on sepolicy.rule static rules."
fi

log "---> post-fs-data done <---"
