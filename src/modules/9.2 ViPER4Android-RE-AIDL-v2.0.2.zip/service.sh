#!/system/bin/sh
MODDIR=${0%/*}

V4A_LOG=/data/adb/viper_install.log
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [service] $1" >> $V4A_LOG; }

log "---> service.sh start <---"

EFFECT_LIB="libv4a_aidl.so"
MOD_VENDOR="$MODDIR/system/vendor"

ns_mount() {
  if nsenter -t 1 -m -- mount -o bind "$1" "$2" 2>/dev/null; then
    return 0
  fi
  mount -o bind "$1" "$2"
}

mount_effect_lib() {
  local SYS_TARGET="$1"
  local MOD_SOURCE_DIR="$2"
  local WORK_DIR="$MODDIR/work_mount$SYS_TARGET"

  if [ ! -d "$SYS_TARGET" ]; then
    log "mount_effect_lib: skip $SYS_TARGET (dir not found)"
    return
  fi
  if [ ! -f "$MOD_SOURCE_DIR/$EFFECT_LIB" ]; then
    log "mount_effect_lib: skip $SYS_TARGET (source lib not found in $MOD_SOURCE_DIR)"
    return
  fi
  if [ -f "$SYS_TARGET/$EFFECT_LIB" ]; then
    log "mount_effect_lib: skip $SYS_TARGET (lib already exists)"
    return
  fi

  [ -d "$WORK_DIR" ] && rm -rf "$WORK_DIR"
  mkdir -p "$WORK_DIR"

  CP_ERR=$(cp -af "$SYS_TARGET"/* "$WORK_DIR/" 2>&1) || log "mount_effect_lib: cp failed $SYS_TARGET -> $WORK_DIR: $CP_ERR"
  cp -f "$MOD_SOURCE_DIR/$EFFECT_LIB" "$WORK_DIR/$EFFECT_LIB"
  CHCON_ERR=$(chcon -R --reference="$SYS_TARGET" "$WORK_DIR" 2>&1) || log "mount_effect_lib: chcon failed $WORK_DIR: $CHCON_ERR"
  ns_mount "$WORK_DIR" "$SYS_TARGET"
  local RC=$?
  log "mount_effect_lib: bind mount $WORK_DIR -> $SYS_TARGET (rc=$RC)"
}

mount_vendor() {
  for arch in lib lib64; do
    mount_effect_lib "/vendor/$arch/soundfx" "$MOD_VENDOR/$arch/soundfx"
  done
}

mount_apex() {
  for sfx_dir in /apex/*/lib64/soundfx /apex/*/lib/soundfx; do
    [ -d "$sfx_dir" ] || continue
    local arch
    case "$sfx_dir" in
      */lib64/*) arch="lib64" ;;
      *)         arch="lib" ;;
    esac
    mount_effect_lib "$sfx_dir" "$MOD_VENDOR/$arch/soundfx"
  done
}

mount_vendor
mount_apex

log "Library presence after mount:"
for d in /vendor/lib/soundfx /vendor/lib64/soundfx /apex/*/lib64/soundfx /apex/*/lib/soundfx; do
  [ -f "$d/$EFFECT_LIB" ] && log "  FOUND: $d/$EFFECT_LIB ($(ls -lZ "$d/$EFFECT_LIB" 2>/dev/null | awk '{print $1, $4, $5}'))"
done

V4A_LIB='<library name="v4a_aidl" path="libv4a_aidl.so"\/>'
V4A_EFFECT='<effect name="v4a_standard_aidl" library="v4a_aidl" uuid="90380da3-8536-4744-a6a3-5731970e640f" type="7261676f-6d75-7369-6364-28e2fd3ac39e"\/>'

MOUNTED=false

mount_config() {
  local original="$1"
  local patched=""

  for p in $(find "$MODDIR/system" -type f -name "$(basename "$original")" 2>/dev/null); do
    local mapped="$(echo "$p" | sed "s|$MODDIR/system/vendor/odm|/odm|; s|$MODDIR/system/vendor|/vendor|; s|$MODDIR/system|/system|")"
    if [ "$mapped" = "$original" ]; then
      patched="$p"
      break
    fi
  done

  if [ -z "$patched" ]; then
    patched="$MODDIR/work_cfg/$(echo "$original" | tr '/' '_')"
    mkdir -p "$MODDIR/work_cfg"
    cp -f "$original" "$patched"
    sed -i "/v4a_standard_aidl/d" "$patched"
    sed -i "/v4a_aidl/d" "$patched"
    if grep -q '<libraries>' "$patched"; then
      sed -i "/<libraries>/ a\\        $V4A_LIB" "$patched"
      sed -i "/<effects>/ a\\        $V4A_EFFECT" "$patched"
    elif grep -q '<library ' "$patched"; then
      sed -i "/<library /i\\        $V4A_LIB" "$patched"
      if grep -q '<effect ' "$patched"; then
        sed -i "/<effect /i\\        $V4A_EFFECT" "$patched"
      fi
    else
      log "mount_config: skip $original (no library/effect tags found)"
      rm -f "$patched"
      return
    fi
    CHCON_ERR=$(chcon --reference="$original" "$patched" 2>&1) || log "mount_config: chcon failed $patched: $CHCON_ERR"
    local V4A_CNT=$(grep -c 'v4a_aidl' "$patched" 2>/dev/null)
    log "Config patched on-the-fly: $original (v4a_aidl entries in patched: $V4A_CNT)"
  fi

  if cmp -s "$patched" "$original"; then
    log "Config skip: $original (already matches patched)"
    return
  fi

  ns_mount "$patched" "$original"
  local RC=$?
  log "Config mount: $patched -> $original (rc=$RC)"
  MOUNTED=true
}

CONFIG_DIRS="/odm/etc /vendor/etc /system/etc /product/etc /system_ext/etc"

for dir in $CONFIG_DIRS; do
  for cfg in "$dir"/audio_effects*.xml; do
    [ -f "$cfg" ] || continue
    mount_config "$cfg"
  done
done

for sku_dir in /vendor/etc/audio/sku_*; do
  [ -d "$sku_dir" ] || continue
  for cfg in "$sku_dir"/audio_effects*.xml; do
    [ -f "$cfg" ] || continue
    mount_config "$cfg"
  done
done

if [ "$MOUNTED" = true ]; then
  for proc in audioserver secaudiohalaidl audiohalservice audio.service-aidl.mediatek; do
    pids=$(ps -A 2>/dev/null | grep "$proc" | grep -v grep | awk '{print $2}')
    if [ -n "$pids" ]; then
      for pid in $pids; do
        kill "$pid" 2>/dev/null
      done
      log "Killed $proc (pids: $pids)"
    fi
  done
  sleep 2
fi

log "Effective audio configs (from init namespace):"
ns_grep_v4a() {
  local cnt
  cnt=$(nsenter -t 1 -m -- cat "$1" 2>/dev/null | grep -c 'v4a_aidl' 2>/dev/null)
  if [ -z "$cnt" ]; then
    cnt=$(grep -c 'v4a_aidl' "$1" 2>/dev/null)
  fi
  echo "${cnt:-0}"
}
for dir in $CONFIG_DIRS; do
  for cfg in "$dir"/audio_effects*.xml; do
    [ -f "$cfg" ] || continue
    HAS_V4A=$(ns_grep_v4a "$cfg")
    log "  $cfg (v4a entries: $HAS_V4A)"
  done
done
for sku_dir in /vendor/etc/audio/sku_*; do
  [ -d "$sku_dir" ] || continue
  for cfg in "$sku_dir"/audio_effects*.xml; do
    [ -f "$cfg" ] || continue
    HAS_V4A=$(ns_grep_v4a "$cfg")
    log "  $cfg (v4a entries: $HAS_V4A)"
  done
done

log "ro.audio.ignore_effects: $(getprop ro.audio.ignore_effects)"

(
  counter=0
  while [ "$(getprop ro.audio.ignore_effects)" = "true" ] && [ $counter -le 20 ]; do
    resetprop ro.audio.ignore_effects false
    log "resetprop ro.audio.ignore_effects false (attempt $counter)"
    sleep 1
    counter=$((counter + 1))
  done
) >/dev/null 2>&1 &

HAL_PROCS=$(ps -A 2>/dev/null | grep -i audio | grep -v grep | head -10)
if [ -n "$HAL_PROCS" ]; then
  log "Audio processes:"
  echo "$HAL_PROCS" | while read line; do
    log "  $line"
  done
else
  log "Audio processes: none detected"
fi
log "Audio HAL SELinux:"
ps -AZ 2>/dev/null | grep -i audio | grep -v grep | head -10 | while read line; do
  log "  $line"
done

log "---> service.sh done <---"
