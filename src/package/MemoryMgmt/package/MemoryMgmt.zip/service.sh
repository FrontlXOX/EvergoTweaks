#!/system/bin/sh
# service.sh — Magisk/KernelSU late-start. Mirrors init.mt6833.rc + init.everpal.rc (v1).

TAG="[everpal-ram-mgmt]"

write() {
    local path="$1" val="$2"
    if [ -w "$path" ]; then
        echo "$val" > "$path"
        echo "$TAG set $path = $val"
    else
        echo "$TAG SKIP $path (not writable)" >&2
    fi
}

log -t "$TAG" "Applying Everpal RAM & LMKD architecture v1..."

# 1. Detect RAM Size & Set Dynamic Parameters
TOTAL_RAM_KB=$(awk '/MemTotal:/ {print $2}' /proc/meminfo)

if [ "$TOTAL_RAM_KB" -lt 5000000 ]; then
    # 4GB Variant (~3,709,888 kB) -> 100% MemTotal (~3.58 GB ZRAM)
    ZRAM_SIZE_BYTES=3758096384
    MIN_FREE_KB=24576
    BG_LIMIT=64
elif [ "$TOTAL_RAM_KB" -lt 7000000 ]; then
    # 6GB Variant (~5,800,000 kB) -> 75% MemTotal (~4.2 GB ZRAM)
    ZRAM_SIZE_BYTES=4509715660
    MIN_FREE_KB=32768
    BG_LIMIT=96
else
    # 8GB Variant (~7,800,000 kB) -> 75% MemTotal (~5.6 GB ZRAM)
    ZRAM_SIZE_BYTES=6012954214
    MIN_FREE_KB=40960
    BG_LIMIT=128
fi

# Set dynamic userspace cached app limits
setprop persist.sys.fw.bg_apps_limit "$BG_LIMIT"
setprop persist.device_config.activity_manager.max_cached_processes "$BG_LIMIT"
setprop persist.device_config.activity_manager.max_phantom_processes $((BG_LIMIT / 2))

# 2. Kernel VM Watermarks & Swappiness
write /proc/sys/vm/swappiness 80
write /proc/sys/vm/vfs_cache_pressure 80
write /proc/sys/vm/watermark_scale_factor 20
write /proc/sys/vm/min_free_kbytes "$MIN_FREE_KB"
write /proc/sys/vm/extra_free_kbytes 0
write /proc/sys/vm/overcommit_memory 1
write /proc/sys/vm/page-cluster 0

# Dynamic memory compaction at boot
write /proc/sys/vm/compact_memory 1

# 3. Dynamic ZRAM Reconfiguration
if [ -b /dev/block/zram0 ]; then
    CURR_SWAP_SIZE=$(awk '/zram0/ {print $3}' /proc/swaps 2>/dev/null)
    CURR_SWAP_BYTES=$((CURR_SWAP_SIZE * 1024))

    # Re-initialize only if size differs significantly
    DIFF=$((ZRAM_SIZE_BYTES - CURR_SWAP_BYTES))
    if [ "$DIFF" -gt 104857600 ] || [ "$DIFF" -lt -104857600 ]; then
        log -t "$TAG" "Reconfiguring ZRAM to $ZRAM_SIZE_BYTES bytes (LZ4)..."
        swapoff /dev/block/zram0 2>/dev/null
        write /sys/block/zram0/reset 1
        
        if [ -f /sys/block/zram0/comp_algorithm ]; then
            write /sys/block/zram0/comp_algorithm lz4
        fi

        NPROC=$(nproc 2>/dev/null || echo 8)
        write /sys/block/zram0/max_comp_streams "$NPROC"
        write /sys/block/zram0/disksize "$ZRAM_SIZE_BYTES"
        mkswap /dev/block/zram0
        swapon /dev/block/zram0 -p 32767
    fi
fi

# 4. Storage I/O Read-Ahead & Optimization (UFS 2.2)
for queue in /sys/block/sd*/queue; do
    if [ -d "$queue" ]; then
        write "$queue/read_ahead_kb" 512
        write "$queue/nr_requests" 128
        write "$queue/iostats" 0
    fi
done

log -t "$TAG" "Everpal RAM & LMKD architecture v1 applied successfully."
