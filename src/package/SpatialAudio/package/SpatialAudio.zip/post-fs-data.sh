#!/system/bin/sh
MODDIR=${0%/*}

# Set SELinux contexts on vendor overlay files
chcon -R u:object_r:vendor_configs_file:s0 "$MODDIR/system/vendor/etc" 2>/dev/null

# Enforce spatial audio and routing properties before audioserver initialization
resetprop -n persist.vendor.audio.spatializer.speaker_enabled false
resetprop -n ro.audio.spatializer.headtracking_supported false
resetprop -n ro.audio.spatializer.use_legacy_param_query true
resetprop -n ro.audio.monitorRotation false
resetprop -n ro.vendor.audio.us.proximity false
